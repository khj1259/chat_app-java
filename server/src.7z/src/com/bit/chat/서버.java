package com.bit.chat;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ���� extends Thread {

	InputStream is;
	OutputStream os;
	static OutputStream[] osArr = new OutputStream[0];
	static InputStream[] isArr = new InputStream[0];

	����(InputStream is, OutputStream os) {
		this.is = is;
		this.os = os;
	}

	public void run() {
		OutputStreamWriter osw = null;
		BufferedWriter bw = null;
		InputStreamReader isr = null;
		BufferedReader br = null;
		try {
			osw = new OutputStreamWriter(os);
			bw = new BufferedWriter(osw);
			isr = new InputStreamReader(is);
			br = new BufferedReader(isr);

			String msg = br.readLine();
			System.out.println(msg);// ---------------------------------------------------
			String[] msgArr = msg.split(" ");

			if (msgArr[0].equals("�ߺ�üũ")) {
				���� f = new ����(msgArr);
				if (f.suc == true) {
					bw.write("����" + "\n");
					bw.flush();
				} else {
					bw.write("����" + "\n");
					bw.flush();
				}

			} else if (msgArr[0].equals("ȸ������")) {
				���� f = new ����(msgArr);
			} else if (msgArr[0].equals("�α���")) {
				���� f = new ����(msgArr);
				if (f.loginBool == true) {
					bw.write("����" + "\n");
					bw.flush();
				} else {
					bw.write("����" + "\n");
					bw.flush();
				}
			} 

			// ���� f = new ����(msg);
			// //
			// bw.write("����");
			// bw.flush();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				br.close();
				isr.close();
				is.close();
				bw.close();
				osw.close();

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	public static void main(String[] args) {
		ServerSocket serv = null;

		try {
			serv = new ServerSocket(3000);
			while (true) {
				Socket sock = serv.accept();
				InputStream is = sock.getInputStream();
				OutputStream os = sock.getOutputStream();

				InputStream[] tempIn = new InputStream[����.osArr.length + 1];
				OutputStream[] temp = new OutputStream[����.osArr.length + 1];
				System.arraycopy(����.osArr, 0, temp, 0, ����.osArr.length);
				System.arraycopy(����.isArr, 0, temp, 0, ����.isArr.length);
				temp[����.osArr.length] = os;
				����.osArr = temp;
				����.isArr = tempIn;

				���� ser = new ����(is, os);
				ser.start();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
