package com.bit.chat;

import java.io.File;

public class ���ε� {
	
	public ���ε�(String fileName){
		File f = new File("./downlist/"+fileName);
		
		
	}


	public static void main(String[] args) {

	}

}
