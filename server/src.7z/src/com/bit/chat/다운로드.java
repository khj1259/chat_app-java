package com.bit.chat;

import java.io.File;

public class �ٿ�ε� {
	public �ٿ�ε�(String fileName){
		File f = new File("./downlist/"+fileName);
	}
	public static void main(String[] args) {

	}

}
